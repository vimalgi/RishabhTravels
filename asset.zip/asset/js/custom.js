jQuery(document).ready(function() {
  equalizer();
});

jQuery(window).resize(function() {
  equalizer();
});

jQuery(window).resize(function() {
  equalizer();
});

jQuery(window).resize(function() {
  equalizer();
});



function equalizer() {
  var max = -1;
  $(".pre_vehicle_det_box").css('min-height','auto');
  $('.pre_vehicle_det_box').each(function() {

      var minHeight = $(this).innerHeight();
      max = minHeight > max ? minHeight : max;

  });
  $(".pre_vehicle_det_box").css('min-height', max);

   var max = -1;
  $(".pre_vehicle_det_box a").css('min-height','auto');
  $('.pre_vehicle_det_box a').each(function() {

      var minHeight = $(this).innerHeight();
      max = minHeight > max ? minHeight : max;

  });
}

$('.slider').slick({
 	slidesToShow: 1,
 	slidesToScroll: 1,
 	arrows: true,
 	fade: false,
 	asNavFor: '.slider-nav-thumbnails',
 });

 $('.slider-nav-thumbnails').slick({
 	slidesToShow: 5,
 	slidesToScroll: 1,
 	asNavFor: '.slider',
 	dots: true,
  arrows: true,
 	focusOnSelect: true
  
 });

 $('.slider-nav-thumbnails .slick-slide').removeClass('slick-active');

 $('.slider-nav-thumbnails .slick-slide').eq(0).addClass('slick-active');

 $('.slider').on('beforeChange', function (event, slick, currentSlide, nextSlide) {
 	var mySlideNumber = nextSlide;
 	$('.slider-nav-thumbnails .slick-slide').removeClass('slick-active');
 	$('.slider-nav-thumbnails .slick-slide').eq(mySlideNumber).addClass('slick-active');
});
  
$('.slider').on('afterChange', function(event, slick, currentSlide){   
  $('.content').hide();
  $('.content[data-id=' + (currentSlide + 1) + ']').show();
});
  



